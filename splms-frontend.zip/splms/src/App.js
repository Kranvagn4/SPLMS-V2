import React from 'react';
import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import Entry from './pages/Entry';
import Exit from './pages/Exit';
import Search from './pages/Search';
import History from './pages/History';
import Analytics from './pages/Analytics';

const nav = [
  { to: '/', label: '🏠 Dashboard' },
  { to: '/entry', label: '🚗 Entry' },
  { to: '/exit', label: '🚪 Exit' },
  { to: '/search', label: '🔍 Search' },
  { to: '/history', label: '📋 History' },
  { to: '/analytics', label: '📊 Analytics' },
];

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-gray-100">
        <nav className="bg-blue-700 text-white shadow-md">
          <div className="max-w-6xl mx-auto px-4 py-3 flex flex-wrap gap-2 items-center">
            <span className="font-bold text-lg mr-4">🅿️ SPLMS</span>
            {nav.map(n => (
              <NavLink
                key={n.to}
                to={n.to}
                end={n.to === '/'}
                className={({ isActive }) =>
                  `px-3 py-1 rounded text-sm font-medium transition-colors ${
                    isActive ? 'bg-white text-blue-700' : 'hover:bg-blue-600'
                  }`
                }
              >
                {n.label}
              </NavLink>
            ))}
          </div>
        </nav>
        <main className="max-w-6xl mx-auto px-4 py-6">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/entry" element={<Entry />} />
            <Route path="/exit" element={<Exit />} />
            <Route path="/search" element={<Search />} />
            <Route path="/history" element={<History />} />
            <Route path="/analytics" element={<Analytics />} />
          </Routes>
        </main>
        <footer className="text-center text-xs text-gray-400 py-4">
          Smart Parking Lot Management System — Demo Mode (data resets on refresh)
        </footer>
      </div>
    </BrowserRouter>
  );
}
