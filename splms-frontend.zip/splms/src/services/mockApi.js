// In-memory store — simulates the Spring Boot backend
// All data resets on page refresh (demo mode)

const PRICING = {
  CAR:   { first: 50,  extra: 20 },
  BIKE:  { first: 20,  extra: 10 },
  TRUCK: { first: 100, extra: 50 },
};

// Seed floors + spots
const floors = [
  { floorId: 1, floorNumber: 1 },
  { floorId: 2, floorNumber: 2 },
  { floorId: 3, floorNumber: 3 },
];

let spots = [];
let spotId = 1;
const config = [
  // [floor, type, count]
  [1, "CAR", 10], [1, "BIKE", 8], [1, "TRUCK", 2],
  [2, "CAR", 12], [2, "BIKE", 6], [2, "TRUCK", 2],
  [3, "CAR", 8],  [3, "BIKE", 6], [3, "TRUCK", 1],
];
config.forEach(([floor, type, count]) => {
  for (let i = 0; i < count; i++) {
    spots.push({ spotId: spotId++, floorId: floor, spotNumber: i + 1, spotType: type, status: "AVAILABLE" });
  }
});

let tickets = [];
let ticketCounter = 1000;

function calcFee(type, entryTime, exitTime) {
  const mins = Math.max(1, Math.round((exitTime - entryTime) / 60000));
  const hours = Math.ceil(mins / 60);
  const p = PRICING[type];
  if (hours <= 1) return p.first;
  return p.first + (hours - 1) * p.extra;
}

export const api = {
  // GET /api/floors/availability
  getFloorAvailability() {
    return floors.map(f => ({
      floorId: f.floorId,
      floorNumber: f.floorNumber,
      available: spots.filter(s => s.floorId === f.floorId && s.status === "AVAILABLE").length,
      total: spots.filter(s => s.floorId === f.floorId).length,
    }));
  },

  // GET /api/vehicles/availability
  getVehicleAvailability() {
    const types = ["CAR", "BIKE", "TRUCK"];
    return types.map(t => ({
      type: t,
      available: spots.filter(s => s.spotType === t && s.status === "AVAILABLE").length,
      total: spots.filter(s => s.spotType === t).length,
    }));
  },

  // POST /api/vehicles/entry
  vehicleEntry({ vehicleNumber, vehicleType }) {
    if (!vehicleNumber.trim()) throw new Error("Vehicle number is required");
    const type = vehicleType.toUpperCase();
    const active = tickets.find(t => t.vehicleNumber === vehicleNumber.trim().toUpperCase() && !t.exitTime);
    if (active) throw new Error("Vehicle is already parked (Ticket #" + active.ticketId + ")");

    const spot = spots.find(s => s.spotType === type && s.status === "AVAILABLE");
    if (!spot) throw new Error("No available spots for " + type);

    spot.status = "OCCUPIED";
    const floor = floors.find(f => f.floorId === spot.floorId);
    const ticket = {
      ticketId: ++ticketCounter,
      vehicleNumber: vehicleNumber.trim().toUpperCase(),
      vehicleType: type,
      spotId: spot.spotId,
      spotNumber: spot.spotNumber,
      floorNumber: floor.floorNumber,
      entryTime: new Date(),
      exitTime: null,
      fee: null,
    };
    tickets.push(ticket);
    return ticket;
  },

  // POST /api/vehicles/exit/:ticketId
  vehicleExit(ticketId) {
    const ticket = tickets.find(t => t.ticketId === Number(ticketId));
    if (!ticket) throw new Error("Ticket not found");
    if (ticket.exitTime) throw new Error("Vehicle already exited");

    ticket.exitTime = new Date();
    ticket.fee = calcFee(ticket.vehicleType, ticket.entryTime, ticket.exitTime);
    const spot = spots.find(s => s.spotId === ticket.spotId);
    if (spot) spot.status = "AVAILABLE";
    return ticket;
  },

  // GET /api/vehicles/search/:query
  searchVehicle(query) {
    const q = query.trim().toUpperCase();
    const ticket = tickets.find(t =>
      (t.vehicleNumber === q || String(t.ticketId) === q) && !t.exitTime
    );
    if (!ticket) throw new Error("No active parking found for: " + query);
    return ticket;
  },

  // GET /api/tickets/history
  getHistory() {
    return [...tickets].reverse();
  },

  // GET /api/analytics
  getAnalytics() {
    const today = new Date(); today.setHours(0,0,0,0);
    const todayTickets = tickets.filter(t => new Date(t.entryTime) >= today);
    const revenue = tickets.filter(t => t.fee).reduce((s, t) => s + t.fee, 0);
    const floorCounts = {};
    tickets.forEach(t => { floorCounts[t.floorNumber] = (floorCounts[t.floorNumber] || 0) + 1; });
    const typeCounts = {};
    tickets.forEach(t => { typeCounts[t.vehicleType] = (typeCounts[t.vehicleType] || 0) + 1; });
    const mostFloor = Object.entries(floorCounts).sort((a,b)=>b[1]-a[1])[0];
    const mostType = Object.entries(typeCounts).sort((a,b)=>b[1]-a[1])[0];
    return {
      totalToday: todayTickets.length,
      totalRevenue: revenue,
      currentlyParked: tickets.filter(t => !t.exitTime).length,
      mostUsedFloor: mostFloor ? "Floor " + mostFloor[0] : "N/A",
      mostUsedType: mostType ? mostType[0] : "N/A",
    };
  },

  getPricing: () => ({ ...PRICING }),
};
