import React, { useState, useEffect } from 'react';
import { api } from '../services/mockApi';

export default function Dashboard() {
  const [floors, setFloors] = useState([]);
  const [vehicles, setVehicles] = useState([]);

  const load = () => {
    setFloors(api.getFloorAvailability());
    setVehicles(api.getVehicleAvailability());
  };

  useEffect(() => { load(); }, []);

  const typeIcon = { CAR: '🚗', BIKE: '🏍️', TRUCK: '🚛' };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Parking Dashboard</h1>
        <button onClick={load} className="text-sm bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
          ↻ Refresh
        </button>
      </div>

      <h2 className="text-lg font-semibold text-gray-700 mb-3">Floor Availability</h2>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        {floors.map(f => {
          const pct = Math.round((f.available / f.total) * 100);
          const color = pct > 50 ? 'bg-green-500' : pct > 20 ? 'bg-yellow-500' : 'bg-red-500';
          return (
            <div key={f.floorId} className="bg-white rounded-xl shadow p-5">
              <p className="text-gray-500 text-sm">Floor {f.floorNumber}</p>
              <p className="text-3xl font-bold text-gray-800">{f.available}</p>
              <p className="text-xs text-gray-400 mb-2">of {f.total} spots free</p>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className={`${color} h-2 rounded-full`} style={{ width: pct + '%' }} />
              </div>
            </div>
          );
        })}
      </div>

      <h2 className="text-lg font-semibold text-gray-700 mb-3">Vehicle Type Availability</h2>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {vehicles.map(v => (
          <div key={v.type} className="bg-white rounded-xl shadow p-5 flex items-center gap-4">
            <span className="text-4xl">{typeIcon[v.type]}</span>
            <div>
              <p className="text-gray-500 text-sm">{v.type}</p>
              <p className="text-2xl font-bold text-gray-800">{v.available} <span className="text-sm font-normal text-gray-400">/ {v.total}</span></p>
              <p className="text-xs text-gray-400">spots available</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
