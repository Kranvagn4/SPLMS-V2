import React, { useState } from 'react';
import { api } from '../services/mockApi';

export default function Entry() {
  const [form, setForm] = useState({ vehicleNumber: '', vehicleType: 'CAR' });
  const [ticket, setTicket] = useState(null);
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    setTicket(null);
    try {
      const t = api.vehicleEntry(form);
      setTicket(t);
      setForm({ vehicleNumber: '', vehicleType: 'CAR' });
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="max-w-lg mx-auto">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Vehicle Entry</h1>

      <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow p-6 space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Vehicle Number</label>
          <input
            type="text"
            placeholder="e.g. MH-12-AB-1234"
            value={form.vehicleNumber}
            onChange={e => setForm({ ...form, vehicleNumber: e.target.value })}
            className="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Vehicle Type</label>
          <select
            value={form.vehicleType}
            onChange={e => setForm({ ...form, vehicleType: e.target.value })}
            className="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="CAR">🚗 Car</option>
            <option value="BIKE">🏍️ Bike</option>
            <option value="TRUCK">🚛 Truck</option>
          </select>
        </div>
        {error && <p className="text-red-600 text-sm bg-red-50 p-3 rounded-lg">{error}</p>}
        <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 font-medium">
          Assign Spot & Generate Ticket
        </button>
      </form>

      {ticket && (
        <div className="mt-6 bg-green-50 border border-green-200 rounded-xl p-6">
          <h2 className="text-lg font-bold text-green-800 mb-4">✅ Parking Ticket Generated</h2>
          <div className="space-y-2 text-sm">
            {[
              ['Ticket ID', '#' + ticket.ticketId],
              ['Vehicle', ticket.vehicleNumber],
              ['Type', ticket.vehicleType],
              ['Floor', 'Floor ' + ticket.floorNumber],
              ['Spot', 'Spot #' + ticket.spotNumber],
              ['Entry Time', new Date(ticket.entryTime).toLocaleString()],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between">
                <span className="text-gray-500">{k}</span>
                <span className="font-semibold text-gray-800">{v}</span>
              </div>
            ))}
          </div>
          <p className="mt-4 text-xs text-green-700 font-medium">Save your Ticket ID for exit: <strong>#{ticket.ticketId}</strong></p>
        </div>
      )}
    </div>
  );
}
