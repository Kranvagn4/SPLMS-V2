import React, { useState, useEffect } from 'react';
import { api } from '../services/mockApi';

export default function History() {
  const [tickets, setTickets] = useState([]);

  useEffect(() => { setTickets(api.getHistory()); }, []);

  const typeIcon = { CAR: '🚗', BIKE: '🏍️', TRUCK: '🚛' };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Parking History</h1>
        <button onClick={() => setTickets(api.getHistory())} className="text-sm bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
          ↻ Refresh
        </button>
      </div>

      {tickets.length === 0 ? (
        <div className="bg-white rounded-xl shadow p-10 text-center text-gray-400">
          No parking history yet. Try entering a vehicle first.
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b">
              <tr>
                {['Ticket', 'Vehicle', 'Type', 'Floor/Spot', 'Entry', 'Exit', 'Fee', 'Status'].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-gray-600 font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {tickets.map(t => (
                <tr key={t.ticketId} className="border-b hover:bg-gray-50">
                  <td className="px-4 py-3 font-mono text-blue-600">#{t.ticketId}</td>
                  <td className="px-4 py-3 font-medium">{t.vehicleNumber}</td>
                  <td className="px-4 py-3">{typeIcon[t.vehicleType]} {t.vehicleType}</td>
                  <td className="px-4 py-3">F{t.floorNumber} / S{t.spotNumber}</td>
                  <td className="px-4 py-3 text-xs">{new Date(t.entryTime).toLocaleString()}</td>
                  <td className="px-4 py-3 text-xs">{t.exitTime ? new Date(t.exitTime).toLocaleString() : '—'}</td>
                  <td className="px-4 py-3">{t.fee != null ? '₹' + t.fee : '—'}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${t.exitTime ? 'bg-gray-100 text-gray-600' : 'bg-green-100 text-green-700'}`}>
                      {t.exitTime ? 'Exited' : 'Parked'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
