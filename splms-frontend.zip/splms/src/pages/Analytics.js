import React, { useState, useEffect } from 'react';
import { api } from '../services/mockApi';

export default function Analytics() {
  const [data, setData] = useState(null);
  const [pricing, setPricing] = useState({});

  useEffect(() => {
    setData(api.getAnalytics());
    setPricing(api.getPricing());
  }, []);

  if (!data) return null;

  const stats = [
    { label: 'Vehicles Today', value: data.totalToday, icon: '📅' },
    { label: 'Currently Parked', value: data.currentlyParked, icon: '🅿️' },
    { label: 'Total Revenue', value: '₹' + data.totalRevenue, icon: '💰' },
    { label: 'Most Used Floor', value: data.mostUsedFloor, icon: '🏢' },
    { label: 'Most Used Type', value: data.mostUsedType, icon: '🚘' },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Analytics Dashboard</h1>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
        {stats.map(s => (
          <div key={s.label} className="bg-white rounded-xl shadow p-4 text-center">
            <div className="text-2xl mb-1">{s.icon}</div>
            <div className="text-xl font-bold text-gray-800">{s.value}</div>
            <div className="text-xs text-gray-400 mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      <h2 className="text-lg font-semibold text-gray-700 mb-3">Pricing Rules</h2>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {Object.entries(pricing).map(([type, p]) => {
          const icons = { CAR: '🚗', BIKE: '🏍️', TRUCK: '🚛' };
          return (
            <div key={type} className="bg-white rounded-xl shadow p-5">
              <p className="font-bold text-gray-700 mb-3">{icons[type]} {type}</p>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">First hour</span>
                  <span className="font-semibold">₹{p.first}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Each extra hour</span>
                  <span className="font-semibold">₹{p.extra}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
