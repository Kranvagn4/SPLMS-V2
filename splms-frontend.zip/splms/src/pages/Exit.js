import React, { useState } from 'react';
import { api } from '../services/mockApi';

function duration(entry, exit) {
  const mins = Math.round((new Date(exit) - new Date(entry)) / 60000);
  const h = Math.floor(mins / 60), m = mins % 60;
  return h > 0 ? `${h}h ${m}m` : `${m}m`;
}

export default function Exit() {
  const [ticketId, setTicketId] = useState('');
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    setResult(null);
    try {
      const t = api.vehicleExit(ticketId);
      setResult(t);
      setTicketId('');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="max-w-lg mx-auto">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Vehicle Exit</h1>

      <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow p-6 space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Ticket ID</label>
          <input
            type="number"
            placeholder="Enter ticket number (e.g. 1001)"
            value={ticketId}
            onChange={e => setTicketId(e.target.value)}
            className="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>
        {error && <p className="text-red-600 text-sm bg-red-50 p-3 rounded-lg">{error}</p>}
        <button type="submit" className="w-full bg-red-600 text-white py-2 rounded-lg hover:bg-red-700 font-medium">
          Process Exit & Calculate Fee
        </button>
      </form>

      {result && (
        <div className="mt-6 bg-blue-50 border border-blue-200 rounded-xl p-6">
          <h2 className="text-lg font-bold text-blue-800 mb-4">🚪 Exit Processed</h2>
          <div className="space-y-2 text-sm">
            {[
              ['Vehicle', result.vehicleNumber],
              ['Type', result.vehicleType],
              ['Floor', 'Floor ' + result.floorNumber],
              ['Entry Time', new Date(result.entryTime).toLocaleString()],
              ['Exit Time', new Date(result.exitTime).toLocaleString()],
              ['Duration', duration(result.entryTime, result.exitTime)],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between">
                <span className="text-gray-500">{k}</span>
                <span className="font-semibold text-gray-800">{v}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 bg-white rounded-lg p-4 text-center">
            <p className="text-gray-500 text-sm">Total Fee</p>
            <p className="text-3xl font-bold text-blue-700">₹{result.fee}</p>
          </div>
        </div>
      )}
    </div>
  );
}
