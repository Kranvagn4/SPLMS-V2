import React, { useState } from 'react';
import { api } from '../services/mockApi';

export default function Search() {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');

  const handleSearch = (e) => {
    e.preventDefault();
    setError('');
    setResult(null);
    try {
      setResult(api.searchVehicle(query));
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="max-w-lg mx-auto">
      <h1 className="text-2xl font-bold text-gray-800 mb-6">Search Vehicle</h1>

      <form onSubmit={handleSearch} className="bg-white rounded-xl shadow p-6 space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Vehicle Number or Ticket ID</label>
          <input
            type="text"
            placeholder="e.g. MH-12-AB-1234 or 1001"
            value={query}
            onChange={e => setQuery(e.target.value)}
            className="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
        </div>
        {error && <p className="text-red-600 text-sm bg-red-50 p-3 rounded-lg">{error}</p>}
        <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 font-medium">
          Search
        </button>
      </form>

      {result && (
        <div className="mt-6 bg-white border rounded-xl shadow p-6">
          <h2 className="text-lg font-bold text-gray-800 mb-4">🔍 Vehicle Found</h2>
          <div className="space-y-2 text-sm">
            {[
              ['Ticket ID', '#' + result.ticketId],
              ['Vehicle', result.vehicleNumber],
              ['Type', result.vehicleType],
              ['Floor', 'Floor ' + result.floorNumber],
              ['Spot', 'Spot #' + result.spotNumber],
              ['Entry Time', new Date(result.entryTime).toLocaleString()],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between border-b pb-2">
                <span className="text-gray-500">{k}</span>
                <span className="font-semibold text-gray-800">{v}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
