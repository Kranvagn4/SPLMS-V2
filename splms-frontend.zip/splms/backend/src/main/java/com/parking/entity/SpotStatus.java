package com.parking.entity;

public enum SpotStatus {
    AVAILABLE, OCCUPIED
}
