-- Smart Parking Lot Management System - Database Schema
CREATE DATABASE IF NOT EXISTS splms_db;
USE splms_db;

-- Floors table
CREATE TABLE IF NOT EXISTS floors (
  floor_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  floor_number INT NOT NULL UNIQUE,
  floor_name VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Parking spots table
CREATE TABLE IF NOT EXISTS parking_spots (
  spot_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  floor_id BIGINT NOT NULL,
  spot_number VARCHAR(20) NOT NULL,
  spot_type ENUM('CAR', 'BIKE', 'TRUCK') NOT NULL,
  status ENUM('AVAILABLE', 'OCCUPIED') DEFAULT 'AVAILABLE',
  UNIQUE KEY uq_spot (floor_id, spot_number),
  FOREIGN KEY (floor_id) REFERENCES floors(floor_id)
);

-- Vehicles table
CREATE TABLE IF NOT EXISTS vehicles (
  vehicle_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  vehicle_number VARCHAR(20) NOT NULL,
  vehicle_type ENUM('CAR', 'BIKE', 'TRUCK') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Parking tickets table
CREATE TABLE IF NOT EXISTS parking_tickets (
  ticket_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  ticket_code VARCHAR(20) NOT NULL UNIQUE,
  vehicle_id BIGINT NOT NULL,
  spot_id BIGINT NOT NULL,
  entry_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  exit_time TIMESTAMP NULL,
  fee DECIMAL(10, 2) NULL,
  status ENUM('ACTIVE', 'COMPLETED') DEFAULT 'ACTIVE',
  FOREIGN KEY (vehicle_id) REFERENCES vehicles(vehicle_id),
  FOREIGN KEY (spot_id) REFERENCES parking_spots(spot_id)
);

-- Pricing rules table (configurable)
CREATE TABLE IF NOT EXISTS pricing_rules (
  rule_id BIGINT AUTO_INCREMENT PRIMARY KEY,
  vehicle_type ENUM('CAR', 'BIKE', 'TRUCK') NOT NULL UNIQUE,
  first_hour_rate DECIMAL(10, 2) NOT NULL,
  additional_hour_rate DECIMAL(10, 2) NOT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Seed: Floors
INSERT INTO floors (floor_number, floor_name) VALUES
  (1, 'Ground Floor'),
  (2, 'First Floor'),
  (3, 'Second Floor');

-- Seed: Parking spots (Floor 1: 40 spots - 20 Car, 15 Bike, 5 Truck)
INSERT INTO parking_spots (floor_id, spot_number, spot_type) VALUES
  (1,'C-101','CAR'),(1,'C-102','CAR'),(1,'C-103','CAR'),(1,'C-104','CAR'),(1,'C-105','CAR'),
  (1,'C-106','CAR'),(1,'C-107','CAR'),(1,'C-108','CAR'),(1,'C-109','CAR'),(1,'C-110','CAR'),
  (1,'C-111','CAR'),(1,'C-112','CAR'),(1,'C-113','CAR'),(1,'C-114','CAR'),(1,'C-115','CAR'),
  (1,'C-116','CAR'),(1,'C-117','CAR'),(1,'C-118','CAR'),(1,'C-119','CAR'),(1,'C-120','CAR'),
  (1,'B-101','BIKE'),(1,'B-102','BIKE'),(1,'B-103','BIKE'),(1,'B-104','BIKE'),(1,'B-105','BIKE'),
  (1,'B-106','BIKE'),(1,'B-107','BIKE'),(1,'B-108','BIKE'),(1,'B-109','BIKE'),(1,'B-110','BIKE'),
  (1,'B-111','BIKE'),(1,'B-112','BIKE'),(1,'B-113','BIKE'),(1,'B-114','BIKE'),(1,'B-115','BIKE'),
  (1,'T-101','TRUCK'),(1,'T-102','TRUCK'),(1,'T-103','TRUCK'),(1,'T-104','TRUCK'),(1,'T-105','TRUCK');

-- Seed: Parking spots (Floor 2: 45 spots - 20 Car, 15 Bike, 10 Truck)
INSERT INTO parking_spots (floor_id, spot_number, spot_type) VALUES
  (2,'C-201','CAR'),(2,'C-202','CAR'),(2,'C-203','CAR'),(2,'C-204','CAR'),(2,'C-205','CAR'),
  (2,'C-206','CAR'),(2,'C-207','CAR'),(2,'C-208','CAR'),(2,'C-209','CAR'),(2,'C-210','CAR'),
  (2,'C-211','CAR'),(2,'C-212','CAR'),(2,'C-213','CAR'),(2,'C-214','CAR'),(2,'C-215','CAR'),
  (2,'C-216','CAR'),(2,'C-217','CAR'),(2,'C-218','CAR'),(2,'C-219','CAR'),(2,'C-220','CAR'),
  (2,'B-201','BIKE'),(2,'B-202','BIKE'),(2,'B-203','BIKE'),(2,'B-204','BIKE'),(2,'B-205','BIKE'),
  (2,'B-206','BIKE'),(2,'B-207','BIKE'),(2,'B-208','BIKE'),(2,'B-209','BIKE'),(2,'B-210','BIKE'),
  (2,'B-211','BIKE'),(2,'B-212','BIKE'),(2,'B-213','BIKE'),(2,'B-214','BIKE'),(2,'B-215','BIKE'),
  (2,'T-201','TRUCK'),(2,'T-202','TRUCK'),(2,'T-203','TRUCK'),(2,'T-204','TRUCK'),(2,'T-205','TRUCK'),
  (2,'T-206','TRUCK'),(2,'T-207','TRUCK'),(2,'T-208','TRUCK'),(2,'T-209','TRUCK'),(2,'T-210','TRUCK');

-- Seed: Parking spots (Floor 3: 30 spots - 10 Car, 10 Bike, 10 Truck)
INSERT INTO parking_spots (floor_id, spot_number, spot_type) VALUES
  (3,'C-301','CAR'),(3,'C-302','CAR'),(3,'C-303','CAR'),(3,'C-304','CAR'),(3,'C-305','CAR'),
  (3,'C-306','CAR'),(3,'C-307','CAR'),(3,'C-308','CAR'),(3,'C-309','CAR'),(3,'C-310','CAR'),
  (3,'B-301','BIKE'),(3,'B-302','BIKE'),(3,'B-303','BIKE'),(3,'B-304','BIKE'),(3,'B-305','BIKE'),
  (3,'B-306','BIKE'),(3,'B-307','BIKE'),(3,'B-308','BIKE'),(3,'B-309','BIKE'),(3,'B-310','BIKE'),
  (3,'T-301','TRUCK'),(3,'T-302','TRUCK'),(3,'T-303','TRUCK'),(3,'T-304','TRUCK'),(3,'T-305','TRUCK'),
  (3,'T-306','TRUCK'),(3,'T-307','TRUCK'),(3,'T-308','TRUCK'),(3,'T-309','TRUCK'),(3,'T-310','TRUCK');

-- Seed: Pricing rules
INSERT INTO pricing_rules (vehicle_type, first_hour_rate, additional_hour_rate) VALUES
  ('CAR', 50.00, 20.00),
  ('BIKE', 20.00, 10.00),
  ('TRUCK', 100.00, 50.00);
